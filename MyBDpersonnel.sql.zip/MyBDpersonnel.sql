-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 19 Juillet 2022 à 22:45
-- Version du serveur: 5.0.45
-- Version de PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `gestionpersonnel`
--

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

CREATE TABLE `absence` (
  `numero` int(11) NOT NULL auto_increment,
  `date_pointage` date NOT NULL,
  `journe` char(10) NOT NULL,
  `matricule` int(11) NOT NULL,
  `nom_ab` varchar(50) NOT NULL,
  `prenom_ab` varchar(50) NOT NULL,
  `categorie` varchar(50) NOT NULL,
  `statut` varchar(10) NOT NULL,
  PRIMARY KEY  (`numero`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=845 ;

--
-- Contenu de la table `absence`
--

INSERT INTO `absence` (`numero`, `date_pointage`, `journe`, `matricule`, `nom_ab`, `prenom_ab`, `categorie`, `statut`) VALUES
(843, '2022-07-18', 'apres-midi', 120, 'RAHERITIANA', 'Joelline', '', 'present'),
(844, '2022-07-18', 'apres-midi', 120, 'RAHERITIANA', 'Joelline', 'Principal', 'absent(e)');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_cat` char(10) NOT NULL,
  `design` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_cat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`id_cat`, `design`) VALUES
('ECD', 'Employé à Courte Durée'),
('EFA', 'Employé Fonctionnaire Administratif'),
('EMO', 'Employé de la Main d''Oeuvre'),
('Fonct.', 'Fonctionnaire');

-- --------------------------------------------------------

--
-- Structure de la table `conge`
--

CREATE TABLE `conge` (
  `numerotation` int(11) NOT NULL auto_increment,
  `date_conge` date NOT NULL,
  `matricule` int(11) NOT NULL,
  `nom_co` varchar(50) NOT NULL,
  `prenom_co` varchar(50) NOT NULL,
  `fonction` varchar(50) NOT NULL,
  `motif` varchar(255) NOT NULL,
  `nbr_jour` int(2) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `etat_conge` varchar(15) NOT NULL,
  PRIMARY KEY  (`numerotation`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `conge`
--

INSERT INTO `conge` (`numerotation`, `date_conge`, `matricule`, `nom_co`, `prenom_co`, `fonction`, `motif`, `nbr_jour`, `date_debut`, `date_fin`, `etat_conge`) VALUES
(9, '2022-07-15', 45, 'RAMANOELISON', 'Andriampahafahana Jese', 'Secretaire', 'Vacance', 1, '2022-07-18', '2022-07-18', 'accorde'),
(10, '2022-07-15', 87, 'RAZAFIMAHARAVO', 'Georges Theophile', 'secretaire', 'Sanitaire', 2, '2022-07-15', '2022-07-18', 'refuse'),
(11, '2022-07-16', 1, 'RABOTOVAO', 'Francois Marcel', 'Inspecteur de marche', 'Vacance', 1, '2022-07-12', '2022-07-12', 'accorde'),
(12, '2022-07-18', 45, 'RAMANOELISON', 'Andriampahafahana Jese', 'Secretaire', '', 2, '2022-07-19', '2022-07-20', 'accorde'),
(13, '2022-07-18', 1, 'RABOTOVAO', 'Francois Marcel', 'Inspecteur de marche', 'Mission', 2, '2022-07-19', '2022-07-20', 'en attente'),
(14, '2022-07-18', 3, 'RAVAONIRINA', 'Charlotte Marie Yvonne', 'Servante', 'Vacance', 1, '2022-07-20', '2022-07-20', 'en attente');

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

CREATE TABLE `personnel` (
  `total_abs` int(5) NOT NULL,
  `conge_restant` int(3) NOT NULL,
  `matricule` int(5) NOT NULL auto_increment,
  `nom_per` varchar(50) NOT NULL,
  `prenom_per` varchar(50) NOT NULL,
  `cin_per` varchar(12) NOT NULL,
  `sexe_per` char(1) NOT NULL,
  `indice` int(5) NOT NULL,
  `fonction` varchar(30) NOT NULL,
  `section` char(10) NOT NULL,
  `cadre` char(10) NOT NULL,
  `date_naiss` date NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `telephone` char(10) NOT NULL,
  `nbr_enfant` int(2) NOT NULL,
  `photo` varchar(50) NOT NULL default 'Unknow2.png',
  PRIMARY KEY  (`matricule`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=121 ;

--
-- Contenu de la table `personnel`
--

INSERT INTO `personnel` (`total_abs`, `conge_restant`, `matricule`, `nom_per`, `prenom_per`, `cin_per`, `sexe_per`, `indice`, `fonction`, `section`, `cadre`, `date_naiss`, `adresse`, `telephone`, `nbr_enfant`, `photo`) VALUES
(11, 41, 1, 'RABOTOVAO', 'Francois Marcel', '', 'H', 515, 'Inspecteur de marche', 'Fonct.', '', '1963-05-18', '', '', 1, ''),
(5, 36, 2, 'RANDRIAMIHANTA', 'Gigi', '', '', 388, 'Manoeuvre', 'EFA', 'VOIRIE', '1963-07-04', '', '', 0, ''),
(9, 39, 3, 'RAVAONIRINA', 'Charlotte Marie Yvonne', '', 'F', 310, 'Servante', 'Fonct.', 'VOIRIE', '1963-08-08', '', '', 0, ''),
(5, 40, 4, 'RAKOTOASIMBOLA', 'Solofonirina Alfred', '', '', 292, 'Police municipal', 'EFA', 'VOIRIE', '1965-01-11', '', '', 1, ''),
(8, 40, 5, 'RASOANANTENAINA', 'Norberthine', '', '', 292, 'Aide percepteur', 'EFA', 'VOIRIE', '1965-04-01', '', '', 0, ''),
(11, 40, 6, 'RANDRIANASOLO', 'Claude', '', '', 268, 'peintre', 'EFA', 'VOIRIE', '1965-09-21', '', '', 0, ''),
(11, 38, 7, 'TSIMANDRIONA', '', '', '', 388, 'Manoeuvre', 'EFA', 'VOIRIE', '1965-12-20', '', '', 1, ''),
(12, 40, 8, 'RAKOTOMALALA', 'Jean Celestin', '', '', 455, 'Manoeuvre', 'Fonct.', 'VOIRIE', '1966-09-28', '', '', 1, ''),
(11, 39, 9, 'RALAIVAO', 'Jean Paul', '', '', 375, 'Chauffeur ', 'Fonct.', 'VOIRIE', '1967-01-04', '', '', 2, ''),
(11, 40, 10, 'RALALARISOA', 'Aimee', '', '', 515, 'Aide percepteur', 'Fonct.', 'CUA', '1967-11-22', '', '', 1, ''),
(12, 39, 11, 'RANDRIAMANILONY', 'Lucie', '', '', 455, 'Secretaire ', 'Fonct.', 'VOIRIE', '1968-05-12', '', '', 0, ''),
(11, 39, 12, 'RASOAMAMPIONONA', 'Juliette', '', '', 455, 'Secretaire', 'EFA', 'VOIRIE', '1968-07-10', '', '', 1, ''),
(12, 40, 13, 'RAHERIMANDIMBY', 'Zazatsy Henri', '', '', 404, 'Animateur', 'Fonct.', 'VOIRIE', '1968-07-13', '', '', 0, ''),
(12, 40, 14, 'VOLOMAVOARISOA', 'Philippe Henriette', '', '', 415, 'Aide percepteur', 'Fonct.', 'VOIRIE', '1968-10-15', '', '', 0, ''),
(10, 40, 15, 'RASOAFARA', 'Vololohanitra Michel', '', '', 264, 'Secretaire', 'EFA', 'CUA', '1969-01-18', '', '', 1, ''),
(11, 40, 16, 'RASOLOFO', 'Janick', '', '', 268, 'gardien', 'EFA', 'VOIRIE', '1969-02-18', '', '', 1, ''),
(11, 41, 17, 'RANDRIANANDRASANA', 'Jean Pierre', '', '', 292, 'Manoeuvre', 'EFA', 'VOIRIE', '1969-04-27', '', '', 1, ''),
(11, 40, 18, 'RAVONIARISOA', 'Myriame', '', '', 415, 'secretaire', 'Fonct.', 'VOIRIE', '1969-06-27', '', '', 0, ''),
(9, 40, 19, 'RAZAFIHENINTSOA', 'Rosiat Alphonse', '', '', 388, 'centroleur de bovide', 'EFA', 'CUA', '1969-09-13', '', '', 0, ''),
(8, 40, 20, 'HARILALAO', 'Nivoniaina Razanakolona', '', '', 665, 'Comptable', 'Fonct.', 'CUA', '1969-10-12', '', '', 0, ''),
(10, 40, 21, 'HANITRINIALA', 'Lucie Irene', '', '', 715, 'Secretaire', 'Fonct.', 'CUA', '1969-11-21', '', '', 1, ''),
(11, 40, 22, 'RASOLOFONIRINA', 'Gregoire', '', '', 388, 'secretaire', 'EFA', 'VOIRIE', '1970-02-11', '', '', 1, ''),
(11, 40, 23, 'RAZAFINDRAHOLY', 'Solofotiana Ranaivo', '', '', 268, 'secretaire', 'EFA', 'VOIRIE', '1970-04-06', '', '', 2, ''),
(10, 40, 24, 'RAKOTONDRABETAFIKA', 'Mireille', '', '', 292, 'Aide percepteur', 'EFA', 'CUA', '1970-06-12', '', '', 1, ''),
(11, 40, 25, 'RAKOTONIRINA', 'Arthur', '', '', 438, 'Gardien CLAC', 'Fonct.', 'VOIRIE', '1970-06-18', '', '', 3, ''),
(9, 40, 26, 'RASOLONJATOVO', 'Jean Damatienne', '', '', 540, 'chef service financier', 'Fonct.', 'CUA', '1970-07-18', '', '', 0, ''),
(12, 40, 27, 'ANDRIANIRINA', 'Herizo Nantenaina', '', '', 438, 'Secretaire', 'Fonct.', 'VOIRIE', '1970-07-10', '', '', 3, ''),
(11, 40, 28, 'RAVAOSOLO', 'Francoise', '', '', 268, 'Aide percepteur', 'EFA', 'VOIRIE', '1971-08-27', '', '', 3, ''),
(9, 40, 29, 'ANDRIANARISOA', 'Lalatiana', '', '', 715, 'Agent de poursuite', 'Fonct.', 'CUA', '1972-01-20', '', '', 2, ''),
(11, 40, 30, 'RANDRIANATOAVINA', 'Gilbert', '', '', 435, 'Aide-percepteur', 'Fonct.', 'VOIRIE', '1972-04-23', '', '', 1, ''),
(11, 40, 31, 'RASOLOVELOMANANTSOA', 'Damien Christophe', '', '', 268, 'gardien', 'EFA', 'VOIRIE', '1972-10-09', '', '', 1, ''),
(11, 40, 32, 'RAMIADANJATOVO', 'Yvon', '', '', 284, 'Manoeuvre', 'Fonct.', 'VOIRIE', '1973-04-11', '', '', 5, ''),
(12, 40, 33, 'ANDRIAMAHAVALISOA', 'Nirison Mamitiaray', '', '', 455, 'surveillant', 'Fonct.', 'VOIRIE', '1973-05-11', '', '', 2, ''),
(11, 40, 34, 'RABANIT', 'Yva', '', '', 268, 'Aide percepteur', 'EFA', 'VOIRIE', '1973-06-06', '', '', 0, ''),
(11, 40, 35, 'RANDRIANIRINA', 'Nestor', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1973-12-28', '', '', 4, ''),
(12, 40, 36, 'ZAFIMAMY', 'Randrianandrasana Frederic', '', '', 388, 'Balayeure', 'EFA', 'VOIRIE', '1974-02-06', '', '', 4, ''),
(8, 40, 37, 'RAVONITSOANIRINA', 'Hanitriniaina Andriatiana Rindra', '', '', 415, 'Secretaire', 'Fonct.', 'CUA', '1974-07-03', '', '', 1, ''),
(11, 40, 38, 'RANDIMBISOA', 'Euben Oswald', '', '', 780, 'Animateur CLAC', 'Fonct.', 'VOIRIE', '1974-08-02', '', '', 2, ''),
(9, 40, 39, 'RAVOAVY', 'Mamiarisoa Elysa Rosina', '', '', 715, 'Secretaire d''etat Civil', 'Fonct.', 'CUA', '1974-08-27', '', '', 2, ''),
(12, 40, 40, 'RASOLONDRAIBE', 'Alexis Marie Claude', '', '', 332, 'Aide percepteur', 'Fonct.', 'VOIRIE', '1974-12-08', '', '', 2, ''),
(11, 40, 41, 'SOARIMALALA', 'Aurelie', '', '', 388, 'secretaire', 'Fonct.', 'VOIRIE', '1974-12-15', '', '', 1, ''),
(12, 40, 42, 'ANDRIAMITSINJONIAINA', 'Ignace Armstrong', '', '', 292, 'Police municipal', 'EFA', 'VOIRIE', '1975-01-08', '', '', 2, ''),
(12, 40, 43, 'ANDRIANIRINA', 'Jean Emile', '', '', 455, 'Controleur de bovid', 'Fonct.', 'VOIRIE', '1975-06-09', '', '', 4, ''),
(11, 40, 44, 'NIVONOMENJANAHARY', 'Ignace Thorene Elisabeth', '', '', 292, 'Secretaire', 'EFA', 'VOIRIE', '1975-09-04', '', '', 2, ''),
(9, 40, 45, 'RAMANOELISON', 'Andriampahafahana Jese', '', '', 1145, 'Secretaire', 'Fonct.', 'CUA', '1976-01-21', '', '', 2, ''),
(11, 40, 46, 'RAFANOMEZANTSOA', 'Joseph', '', '', 560, 'Agent voyer', 'Fonct.', 'VOIRIE', '1976-06-24', '', '', 5, ''),
(12, 40, 47, 'RAZAFINDRAKOTO', 'Grimaud Aim', '', '', 455, 'Plombier', 'Fonct.', 'VOIRIE', '1976-09-26', '', '', 6, ''),
(11, 40, 48, 'RAFANOMEZANALAHINIRIKO', 'Emilson', '', '', 268, 'Gardien stade', 'EFA', 'VOIRIE', '1976-10-26', '', '', 1, ''),
(9, 40, 49, 'RATOLONJANAHARY', 'Harinivo Odilon', '', '', 435, 'Regisseur', 'Fonct.', 'CUA', '1977-02-08', '', '', 3, ''),
(11, 40, 50, 'RAZAFIMAHATRATRA', 'Daniel Elys', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1977-07-13', '', '', 2, ''),
(12, 40, 51, 'MARCELLINE', 'Francoise', '', '', 284, 'aide percepteur', 'EFA', 'VOIRIE', '1977-07-25', '', '', 5, ''),
(11, 40, 52, 'TOVOARIJAONA', 'Solo Anja', '', '', 435, 'Dispensatrice', 'Fonct.', 'VOIRIE', '1978-06-18', '', '', 2, ''),
(8, 40, 53, 'RAMASINARIVO', 'Samuel', '', '', 268, 'Aide percepteur', 'EFA', 'CUA', '1979-02-09', '', '', 3, ''),
(11, 40, 54, 'RAKOTONIAINA', 'Jean Victor', '', '', 264, 'gardien', 'EFA', 'VOIRIE', '1979-03-08', '', '', 3, ''),
(12, 40, 55, 'RATSIMBAZAFY', 'William Pierre', '', '', 268, 'gardien', 'EFA', 'CUA', '1979-03-18', '', '', 6, ''),
(11, 40, 56, 'TAFIKA', 'Clay', '', '', 284, 'Electricien', 'EFA', 'VOIRIE', '1979-04-10', '', '', 2, ''),
(11, 40, 57, 'RANDRIANARIZAFINDRAKOTO', 'Noel Roselin Xavier', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1979-06-02', '', '', 2, ''),
(9, 40, 58, 'RASOLONIRINA', 'Xavier Petera Frederic', '', '', 268, 'platon', 'EFA', 'CUA', '1980-04-29', '', '', 3, ''),
(11, 40, 59, 'RAZAFIMANDIMBY', 'Raymond Justin', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1980-12-27', '', '', 5, ''),
(11, 40, 60, 'TOLOARINJAKA', 'Santatriniaina Clermont', '', '', 268, 'Police municipal', 'EFA', 'VOIRIE', '1981-10-04', '', '', 1, ''),
(11, 40, 61, 'RASOLOMAMPIONONA', 'Fenosoa Alain Patrick', '', '', 264, 'Manoeuvre', 'EFA', 'VOIRIE', '1981-10-06', '', '', 3, ''),
(9, 40, 62, 'RAHANTAMALALA', 'Solange Justine', '', '', 284, 'secretaire', 'EFA', 'CUA', '1982-05-10', '', '', 2, ''),
(11, 40, 63, 'HERINIAINA', 'Raoul Patrice', '', '', 268, 'Police municipal', 'EFA', 'VOIRIE', '1982-09-16', '', '', 3, ''),
(11, 40, 64, 'TOLOTRINIAINA', 'Nomenjanahary Toussaint', '', '', 268, 'chauffeur', 'EFA', 'VOIRIE', '1983-09-26', '', '', 2, ''),
(11, 40, 65, 'RAKOTOARISOA', 'Andrianandrasana', '', '', 372, 'aide percepteur', 'EFA', 'VOIRIE', '1984-01-27', '', '', 2, ''),
(8, 40, 66, 'ANDRIANAMBININTSOA', 'Naivoson Emile Dolly', '', '', 388, 'secretaire', 'EFA', 'CUA', '1985-08-04', '', '', 4, ''),
(11, 40, 67, 'TOLOTRARISON', 'Jean Emilien', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1987-10-05', '', '', 0, ''),
(11, 40, 68, 'RAKOTOSON', 'Andrianarijaona Tahina', '', '', 438, 'Manoeuvre', 'EFA', 'VOIRIE', '1988-01-12', '', '', 2, ''),
(11, 40, 69, 'RASOLONIANA', 'Jean Roger', '', '', 264, 'Manoeuvre', 'EFA', 'VOIRIE', '1988-07-04', '', '', 3, ''),
(11, 40, 70, 'SOLONDRAINY', 'Jean Baptiste', '', '', 264, 'Manoeuvre', 'EFA', 'VOIRIE', '1989-02-20', '', '', 2, ''),
(11, 40, 71, 'MAMINIAINA', 'Jacob', '', '', 264, 'Manoeuvre', 'EFA', 'VOIRIE', '1989-08-20', '', '', 1, ''),
(11, 40, 72, 'RANDRIANIRINA', 'Henri Rapha', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1967-04-14', '', '', 2, ''),
(11, 40, 73, 'RANDRIANANTENAINA', 'Anicet', '', '', 292, 'Manoeuvre', 'EFA', 'VOIRIE', '1967-04-17', '', '', 1, ''),
(11, 40, 74, 'RALAIARIVONY', 'Bialahy Joseph', '', '', 268, 'Manoeuvre', 'EFA', 'VOIRIE', '1978-05-25', '', '', 0, ''),
(12, 40, 75, 'RAKOTOMALALA', 'Marie Hyancinte Aim', '', '', 388, 'Platon', 'EFA', 'VOIRIE', '1962-11-27', '', '', 1, ''),
(8, 40, 76, 'RAVAOARY', 'Juliette Raphaele', '', '', 715, 'Secretaire', 'Fonct.', 'CUA', '1962-09-13', '', '', 0, ''),
(12, 40, 77, 'DANAMARY', 'Emilienne', '', '', 415, 'balayeuse', 'Fonct.', 'VOIRIE', '1962-06-19', '', '', 1, ''),
(11, 40, 78, 'RAKOTOZAFY', ' Marcel', '', '', 455, 'Surveillent ', 'Fonct.', 'VOIRIE', '1962-02-23', '', '', 3, ''),
(11, 40, 80, 'RASOLONDRAIBE', 'Julia', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1984-10-15', '', '', 0, ''),
(11, 40, 81, 'RALAHY', 'Bernadette', '', '', 212, 'balayeuse', 'ECD', 'VOIRIE', '1964-08-03', '', '', 0, ''),
(8, 40, 82, 'MAMIHARISOA', 'Simone Aimee', '', '', 212, 'Secretaire Etat Civil', 'ECD', 'CUA', '1983-09-14', '', '', 0, ''),
(8, 40, 83, 'LOUIS', 'Manana', '', '', 650, 'chef service ', 'ECD', 'CUA', '1967-01-19', '', '', 2, ''),
(11, 40, 84, 'FANEVANDRAIBE', 'Gilbert', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1985-09-13', '', '', 0, ''),
(11, 40, 85, 'RAMAMINIRINA', 'Gilbert', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1981-12-15', '', '', 0, ''),
(8, 40, 86, 'ANDRIAMIHAJA', 'Naivoson Emile Fidele', '', '', 212, 'Manoeuvre', 'ECD', 'CUA', '1977-10-10', '', '', 0, ''),
(8, 40, 87, 'RAZAFIMAHARAVO', 'Georges Theophile', '', '', 212, 'secretaire', 'ECD', 'CUA', '1990-10-10', '', '', 0, ''),
(11, 40, 88, 'HERILALAINA', 'Fidelice', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1981-09-20', '', '', 0, ''),
(11, 40, 89, 'RAKOTOASIMBOLA', 'Sahondranirina', '', '', 350, 'Dispensatrice', 'ECD', 'VOIRIE', '1976-07-11', '', '', 0, ''),
(12, 40, 90, 'RAJOMA', 'Pierre', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1963-07-05', '', '', 0, ''),
(8, 40, 91, 'NOMENJANAHARY', 'Hasiniaina Andriambololona', '', '', 212, 'femme de menage', 'ECD', 'CUA', '1980-02-10', '', '', 0, ''),
(11, 40, 92, 'RAFANOMEZANA', 'Jean Noel Adolphe', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1983-10-04', '', '', 0, ''),
(11, 40, 93, 'RAZAFINIMANANA', 'Voahangilalao Julienne', '', '', 212, 'Balayeuse', 'ECD', 'VOIRIE', '1973-02-10', '', '', 0, ''),
(12, 40, 94, 'RAFANJANIRINA', 'Justine', '', '', 212, 'balayeuse', 'ECD', 'VOIRIE', '1970-06-06', '', '', 0, ''),
(11, 40, 95, 'RASOANJANAHARY', 'Pascaline', '', '', 212, 'balayeuse', 'ECD', 'VOIRIE', '1970-03-28', '', '', 0, ''),
(9, 40, 96, 'RAHANTAVOLOLONIRINA', 'Henriette', '', '', 212, 'femme de menage', 'ECD', 'CUA', '1972-01-08', '', '', 0, ''),
(8, 40, 97, 'RASOAMIARAMANANA', 'Celestine', '', '', 212, 'femme de menage', 'ECD', 'CUA', '1966-12-23', '', '', 0, ''),
(9, 40, 98, 'LALAONIRINA', 'Marina', '', '', 212, 'Agent de poursuite', 'ECD', 'CUA', '0000-00-00', '', '', 0, ''),
(12, 40, 99, 'RATSIMBAZAFY', 'Noel Emma Christian', '', '', 212, 'Aide percepteur Abattoir', 'ECD', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(13, 40, 100, 'RAMAMONJISOA', 'Tsiandrimandimby', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '1979-01-13', '', '', 0, ''),
(15, 40, 101, 'SOLOFOMANDIMBY', 'Paulin', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 102, 'RAKOTONIRINA', 'Benandro', '', '', 212, 'Manoeuvre', 'ECD', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 103, 'RASOANANDRASANA', 'Abeline', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 104, 'RASOAMAMPIONONA', 'Brigitte', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 105, 'RAVAOMALALA', 'Marie Justine', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 106, 'NIRINA', 'Odette Marie Tharcile', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 107, 'VONIMBOAHIRANA', 'Adeline', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 108, 'MAMISOA HARY', 'Tiana', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 109, 'RAHARISOANIAINA', 'Marie Clotilde', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 110, 'RAHARISOA', 'Arvina', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 111, 'RAVAONIRINA', 'Emilienne', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 112, 'RASOANANDRASANA', 'Josephine Marie L', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 113, 'RASOANOMENJANAHARY', 'Solange', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 114, 'HANTAMALALA', 'Marie Nathalie', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 115, 'RASOARIVELO', 'Victorine', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 116, 'RASOA', 'Noeline', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 117, 'ZARASOA', 'Dorena Freurisse', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 118, 'RAVAOHANGINIRINA', 'Louisa inge', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 119, 'SAHOLINIRINA', 'Fideline', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, ''),
(22, 40, 120, 'RAHERITIANA', 'Joelline', '', '', 0, '', 'EMO', 'VOIRIE', '0000-00-00', '', '', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

CREATE TABLE `service` (
  `num` int(5) NOT NULL auto_increment,
  `id_service` char(50) NOT NULL,
  `label_service` varchar(100) NOT NULL,
  PRIMARY KEY  (`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `service`
--

INSERT INTO `service` (`num`, `id_service`, `label_service`) VALUES
(1, 'VOIRIE', 'Secrétariat du VOIRIE'),
(2, 'Secretaire', 'Secrétariat de la CUA'),
(3, 'Principal', 'Administrateur Principale');

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `num` int(2) NOT NULL auto_increment,
  `daty` date NOT NULL,
  `journe` char(10) NOT NULL,
  `titre` varchar(50) NOT NULL,
  `valeur` int(5) NOT NULL,
  PRIMARY KEY  (`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Contenu de la table `stock`
--

INSERT INTO `stock` (`num`, `daty`, `journe`, `titre`, `valeur`) VALUES
(1, '2022-07-15', '', 'absence', 28),
(6, '2022-07-16', '', 'absence', 19),
(15, '2022-07-17', 'matin', 'absence', 6),
(16, '2022-07-17', 'apres-midi', 'absence', 2),
(17, '2022-07-18', 'matin', 'absence', 19),
(22, '2022-07-18', 'apres-midi', 'absence', 1);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(2) NOT NULL auto_increment,
  `type` varchar(30) NOT NULL default 'usr',
  `nom_admin` varchar(50) NOT NULL,
  `prenom_admin` varchar(50) NOT NULL,
  `sexe` char(5) NOT NULL,
  `mail_admin` varchar(50) NOT NULL,
  `tel_admin` varchar(10) NOT NULL,
  `adresse_admin` varchar(50) NOT NULL,
  `photo_admin` varchar(50) NOT NULL default 'Standard.jpg',
  `motdepasse` varchar(15) NOT NULL,
  `code` int(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `type`, `nom_admin`, `prenom_admin`, `sexe`, `mail_admin`, `tel_admin`, `adresse_admin`, `photo_admin`, `motdepasse`, `code`) VALUES
(1, 'VOIRIE', 'Andrianajoro', 'Banadz', 'homme', 'andrianajoro@gmail.com', '0343807986', 'Ambalasoa Ambalavao', 'prof2.jpg', 'vivelevent', 4856),
(2, 'Secretaire', 'HANITRINIALA', 'Lucie Irene', 'femme', 'madameirene@gmail.com', '034*******', '', 'njaka.jpg', 'secretaire', 0),
(5, 'Principal', 'RANDRIANIRINA', 'Yves Georges', 'homme', 'randrianirina.veve@gmail.com', '034*******', 'Avaramanda Ambalavao', '', 'admin_maire', 1947);
